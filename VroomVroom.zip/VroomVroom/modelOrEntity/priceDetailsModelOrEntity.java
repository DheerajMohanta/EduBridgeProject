package com.edubridge.VroomVroom.modelOrEntity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_price_dtls")
public class priceDetailsModelOrEntity {
	@Id
	@GeneratedValue
	int id;
	int bikeId;
	public priceDetailsModelOrEntity() {
		super();
	}
	public priceDetailsModelOrEntity(int id, String brand, String bname, float hcharge, float rto, float scomm,
			float srprice, float pcost, float gst) {
		super();
		this.id = id;
		this.brand = brand;
		this.bname = bname;
		this.hcharge = hcharge;
		this.rto = rto;
		this.scomm = scomm;
		this.srprice = srprice;
		this.pcost = pcost;
		this.gst = gst;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public float getHcharge() {
		return hcharge;
	}
	public void setHcharge(float hcharge) {
		this.hcharge = hcharge;
	}
	public float getRto() {
		return rto;
	}
	public void setRto(float rto) {
		this.rto = rto;
	}
	public float getScomm() {
		return scomm;
	}
	public void setScomm(float scomm) {
		this.scomm = scomm;
	}
	public float getSrprice() {
		return srprice;
	}
	public void setSrprice(float srprice) {
		this.srprice = srprice;
	}
	public float getPcost() {
		return pcost;
	}
	public void setPcost(float pcost) {
		this.pcost = pcost;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	private String brand;
	private String bname;
	private float hcharge;
	private float rto;	
	private float scomm;
	private float srprice;
	private float pcost;
	private float gst;	
}
