package com.edubridge.VroomVroom.modelOrEntity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_user_dtls")
public class signUpModelOrEntity {
	@Id
	@GeneratedValue
	int id;
   	public signUpModelOrEntity() {
		super();
	}
	public signUpModelOrEntity(int id, String f_name, String l_name, String hnum, String street, String addType,
			String phnnum, String lochint, String p_office, String city, String state, String country, Integer pin,
			String email, String passToken, String gender, Date dob) {
		super();
		this.id = id;
		this.f_name = f_name;
		this.l_name = l_name;
		this.hnum = hnum;
		this.street = street;
		this.addType = addType;
		this.phnnum = phnnum;
		this.lochint = lochint;
		this.p_office = p_office;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pin = pin;
		this.email = email;
		this.passToken = passToken;
		this.gender = gender;
		this.dob = dob;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public String getHnum() {
		return hnum;
	}
	public void setHnum(String hnum) {
		this.hnum = hnum;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getAddType() {
		return addType;
	}
	public void setAddType(String addType) {
		this.addType = addType;
	}
	public String getPhnnum() {
		return phnnum;
	}
	public void setPhnnum(String phnnum) {
		this.phnnum = phnnum;
	}
	public String getLochint() {
		return lochint;
	}
	public void setLochint(String lochint) {
		this.lochint = lochint;
	}
	public String getP_office() {
		return p_office;
	}
	public void setP_office(String p_office) {
		this.p_office = p_office;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(Integer pin) {
		this.pin = pin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassToken() {
		return passToken;
	}
	public void setPassToken(String passToken) {
		this.passToken = passToken;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	private String f_name;
    private String l_name;
    private String hnum;
    private String street;
    private String addType;
    private String phnnum;
    private String lochint;
    private String p_office;
    private String city;
    private String state;
    private String country;
    private Integer pin;
    private String email;
    private String passToken;
    private String gender;
    private Date dob;
}
