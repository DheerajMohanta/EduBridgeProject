package com.edubridge.VroomVroom.modelOrEntity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_Bikes_dtls")
public class inventoryMgmtModelOrEntity {
	@Id
	@GeneratedValue
	int id;
	public inventoryMgmtModelOrEntity(int id, String brand, String bname, String engine, String power, String bbreak,
			String tiertype, String abs, String fueltype, String milage, String speed, String torque, String gear,
			String transmission, String lighttype, float price, float gst, String img_path, String img_name) {
		super();
		this.id = id;
		this.brand = brand;
		this.bname = bname;
		this.engine = engine;
		this.power = power;
		this.bbreak = bbreak;
		this.tiertype = tiertype;
		this.abs = abs;
		this.fueltype = fueltype;
		this.milage = milage;
		this.speed = speed;
		this.torque = torque;
		this.gear = gear;
		this.transmission = transmission;
		this.lighttype = lighttype;
		this.price = price;
		this.gst = gst;
		this.img_path = img_path;
		this.img_name = img_name;
	}
	public String getimg_path() {
		return img_path;
	}
	public void setimg_path(String img_path) {
		this.img_path = img_path;
	}
	public String getimg_name() {
		return img_name;
	}
	public void setimg_name(String img_name) {
		this.img_name = img_name;
	}
	public inventoryMgmtModelOrEntity() {
		super();
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getPower() {
		return power;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public String getBbreak() {
		return bbreak;
	}
	public void setBbreak(String bbreak) {
		this.bbreak = bbreak;
	}
	public String getTiertype() {
		return tiertype;
	}
	public void setTiertype(String tiertype) {
		this.tiertype = tiertype;
	}
	public String getAbs() {
		return abs;
	}
	public void setAbs(String abs) {
		this.abs = abs;
	}
	public String getFueltype() {
		return fueltype;
	}
	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}
	public String getMilage() {
		return milage;
	}
	public void setMilage(String milage) {
		this.milage = milage;
	}
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	public String getTorque() {
		return torque;
	}
	public void setTorque(String torque) {
		this.torque = torque;
	}
	public String getGear() {
		return gear;
	}
	public void setGear(String gear) {
		this.gear = gear;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public String getLighttype() {
		return lighttype;
	}
	public void setLighttype(String lighttype) {
		this.lighttype = lighttype;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	private String brand;
	private String bname;
	private String engine;
	private String power;	
	private String bbreak;
	private String tiertype;
	private String abs;
	private String fueltype;
	private String milage;
	private String speed;
	private String torque;
	private String gear;
	private String transmission;
	private String lighttype;
	private float price;
	private float gst;
	private String img_path;
	private String img_name;
}
