package com.edubridge.VroomVroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.VroomVroom.modelOrEntity.priceDetailsModelOrEntity;
import com.edubridge.VroomVroom.repository.priceDetailsRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class priceDetailsController {
	@Autowired
	private priceDetailsRepository pdRepo;
	@RequestMapping("priceDetails")
	public ResponseEntity<List<priceDetailsModelOrEntity>> getAll(){
		List<priceDetailsModelOrEntity> allPriceDtls=pdRepo.findAll();
		return ResponseEntity.ok(allPriceDtls);

	}
}
