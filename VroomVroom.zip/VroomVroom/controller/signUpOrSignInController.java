package com.edubridge.VroomVroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.VroomVroom.modelOrEntity.signUpModelOrEntity;
import com.edubridge.VroomVroom.repository.SignUpRepository;



@RestController
//@RequestMapping(value={"/signin"})
@CrossOrigin(origins = "http://localhost:4200")
public class signUpOrSignInController {
	@Autowired
	private SignUpRepository signUpRepo;
//	@Autowired
//	private SignInRepository signInRepo;
	
	@PostMapping("signup")
	public ResponseEntity<?> signUpUser(@RequestBody signUpModelOrEntity signUpEntityData) {
//		System.out.println("In Controller");
		return ResponseEntity.ok(signUpRepo.save(signUpEntityData));
		
	}
	@PostMapping("signin")
	public ResponseEntity<?> signInUser(@RequestBody signUpModelOrEntity signInEntityData) {
		signUpModelOrEntity signInObj=signUpRepo.findByEmail(signInEntityData.getEmail());
		if(signInObj.getPassToken().equals(signInEntityData.getPassToken()) && signInObj.getEmail().equals(signInEntityData.getEmail()))
			return ResponseEntity.ok(signInObj);
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}
	@RequestMapping("customers")
	public ResponseEntity<List<signUpModelOrEntity>> getAll(){
		System.out.println("Controler");
		List<signUpModelOrEntity> allCustomers=signUpRepo.findAll();
//		return SignUpRepository.getAllUsers();	
		return ResponseEntity.ok(allCustomers);

	}
}
