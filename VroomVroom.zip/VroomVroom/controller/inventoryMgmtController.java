package com.edubridge.VroomVroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.VroomVroom.modelOrEntity.inventoryMgmtModelOrEntity;
import com.edubridge.VroomVroom.modelOrEntity.priceDetailsModelOrEntity;
import com.edubridge.VroomVroom.repository.inventoryMgmtRepository;
import com.edubridge.VroomVroom.repository.priceDetailsRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class inventoryMgmtController {
	@Autowired
	private inventoryMgmtRepository invMgmtRepo;
	@Autowired
	private priceDetailsRepository prcdtlsRepo;
//	@Autowired
	
	@PostMapping("mgntinventory")
	public void inventoryEntry(@RequestBody inventoryMgmtModelOrEntity invMgmtData) {
//	public ResponseEntity<?> inventoryEntry(@RequestBody inventoryMgmtModelOrEntity invMgmtData) {
//		return ResponseEntity.ok(invMgmtRepo.save(invMgmtData));	
		invMgmtRepo.save(invMgmtData);
	}
	@PostMapping("insertPriceDetails")
	public void priceDetailsEntry(@RequestBody priceDetailsModelOrEntity prcdtlsData) {
		prcdtlsRepo.save(prcdtlsData);
	}
//	@GetMapping("bikeDetails/{bikeName}")
//	public ResponseEntity<?> bikeDetailsByName(@PathVariable String bikeName) {
//		inventoryMgmtModelOrEntity bikeInfoObj=invMgmtRepo.getByBname(bikeName);
//		return ResponseEntity.ok(bikeInfoObj);
//		
//	}
	@RequestMapping("bikeDetails")
	public ResponseEntity<List<inventoryMgmtModelOrEntity>> getAll(){
		List<inventoryMgmtModelOrEntity> allBikeInfo=invMgmtRepo.findAll();
		return ResponseEntity.ok(allBikeInfo);

	}
}
