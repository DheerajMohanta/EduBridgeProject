package com.edubridge.VroomVroom.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.VroomVroom.modelOrEntity.signUpModelOrEntity;


public interface SignUpRepository extends JpaRepository<signUpModelOrEntity, Integer>{
	signUpModelOrEntity findByEmail(String email);

}
