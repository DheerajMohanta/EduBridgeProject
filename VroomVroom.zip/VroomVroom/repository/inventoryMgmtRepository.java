package com.edubridge.VroomVroom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.VroomVroom.modelOrEntity.inventoryMgmtModelOrEntity;

public interface inventoryMgmtRepository extends JpaRepository<inventoryMgmtModelOrEntity, Integer>{
	inventoryMgmtModelOrEntity getByBname(String bname);
}
