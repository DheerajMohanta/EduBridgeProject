package com.edubridge.VroomVroom.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edubridge.VroomVroom.modelOrEntity.signInModelOrEntity;
import com.edubridge.VroomVroom.modelOrEntity.signUpModelOrEntity;

@Repository
public interface SignInRepository extends JpaRepository<signInModelOrEntity, String>{
	signInModelOrEntity findByEmail(String email);
}
