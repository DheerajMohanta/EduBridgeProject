package com.edubridge.VroomVroom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.VroomVroom.modelOrEntity.priceDetailsModelOrEntity;

public interface priceDetailsRepository extends JpaRepository<priceDetailsModelOrEntity, Integer>{

}
