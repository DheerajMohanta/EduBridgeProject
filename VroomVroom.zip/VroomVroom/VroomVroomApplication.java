package com.edubridge.VroomVroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VroomVroomApplication {

	public static void main(String[] args) {
		SpringApplication.run(VroomVroomApplication.class, args);
	}

}
