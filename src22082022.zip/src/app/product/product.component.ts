import { Component, OnInit } from '@angular/core';
import { InventorymanagementService } from '../services/inventorymanagement.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private priceObj:InventorymanagementService) {
    this.productionDetailInfo();
   }
   productDetails:any;
productionDetailInfo(){
  this.priceObj.showAllPriceDetails().subscribe((response:any)=>{this.productDetails=response});
}
  ngOnInit(): void {
  }

}
