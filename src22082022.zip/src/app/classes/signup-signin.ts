export class SignupSignin {
    f_name!:String;
    l_name!:String;
    addInput!:String;
    p_office!:String;
    city!:String;
    state!:String;
    country!:String;
    pin!:Number;
    email!:String;
    passToken!:String;
    gender!:String;
    dob!:Date
    // gender = null;
    addType!:String;
}
