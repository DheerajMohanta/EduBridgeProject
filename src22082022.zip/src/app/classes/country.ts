export class Country {
    name!: String;
    alpha2Code!: string;
    alpha3Code!: string;
    numericCode!: string;
    callingCode!: string;
}
