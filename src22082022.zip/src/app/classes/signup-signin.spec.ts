import { SignupSignin } from './signup-signin';

describe('SignupSignin', () => {
  it('should create an instance', () => {
    expect(new SignupSignin()).toBeTruthy();
  });
});
