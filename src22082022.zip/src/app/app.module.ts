import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { NavigatorComponent } from './components/navigator/navigator.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SigninComponent } from './components/signin/signin.component';
import { SignoutComponent } from './components/signout/signout.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SignupComponent } from './components/signup/signup.component'
import {MatDatepickerModule, MatDateSelectionModel} from '@angular/material/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormField, MatHint, MatLabel } from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { ProductComponent } from './product/product.component';
import { OrderComponent } from './order/order.component';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import { RemoveproductComponent } from './components/removeproduct/removeproduct.component';
import { InventorymanagementComponent } from './components/inventorymanagement/inventorymanagement.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { CustomerdetailsComponent } from './components/customerdetails/customerdetails.component';
import { SidenavbarComponent } from './components/sidenavbar/sidenavbar.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavigatorComponent,
    FooterComponent,
    HomeComponent,
    CheckoutComponent,
    DashboardComponent,
    SigninComponent,
    SignoutComponent,
    SignupComponent,
    ForgetPasswordComponent,
    ProductComponent,
    OrderComponent,
    AddproductComponent,
    RemoveproductComponent,
    InventorymanagementComponent,
    AdminloginComponent,
    CustomerdetailsComponent,
    SidenavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatDatepickerModule,
    BrowserAnimationsModule,
    MatNativeDateModule,
    MatInputModule,ReactiveFormsModule
   ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
