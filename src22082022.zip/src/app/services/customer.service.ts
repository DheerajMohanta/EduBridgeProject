import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  urlViewAllCustomer="http://localhost:9192/customers"
  constructor(private http:HttpClient) { }
  viewAllCustomerInfo(){    
    
    return this.http.get(this.urlViewAllCustomer);
  }
}
