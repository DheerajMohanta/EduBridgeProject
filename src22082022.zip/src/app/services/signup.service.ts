import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  regInfoUrl="http://localhost:9192/signup";//
  urlViewAllUsers="http://localhost:9192/allUsers";
  constructor(private signUpHttp:HttpClient) { }/**imported HttpClient and created object to access http operations like [post,get,delete etc] */
  insertRegData(recvdRegInfo:any){
    // console.log(recvdRegInfo);
    return this.signUpHttp.post(this.regInfoUrl, recvdRegInfo)
  }
  state(){ return[{ id:1,name:"Maharastra"},
    { id:2,name:"West Bengal" }]
  }
  city(){ return[ { id:1, name:"Pune" },
      { id:1, name:"Mumbai" },
      { id:2, name:"Kolkata" },
      { id:2, name:"Howrah" } ]
  }

  
}
 