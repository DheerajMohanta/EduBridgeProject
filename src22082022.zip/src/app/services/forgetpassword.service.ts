import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ForgetpasswordService {
  passwordResetUrl="http://localhost:9192/forgetPassword";

  constructor(private forgetpasswordHttp:HttpClient) { }

  findUser(recvdpassUpdRec:any){
    console.log(recvdpassUpdRec);
    return this.forgetpasswordHttp.post(this.passwordResetUrl,recvdpassUpdRec);
  }
  updatePasswordInfo(updatePasswordRec:any){
    return this.forgetpasswordHttp.post(this.passwordResetUrl,updatePasswordRec)
  }
}
