import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InventorymanagementService {
  invMgmtUrl="http://localhost:9192/mgntinventory";
  priceDetailsUrl="http://localhost:9192/insertPriceDetails";
  viewBikeDetailsUrl="http://localhost:9192/bikeDetails";
  viewPriceDetailsUrl="http://localhost:9192/priceDetails";
  constructor(private invMgmtHTTP:HttpClient) { }

  insBikeInfoData(rcvdBikeInfoRec:any){
    return this.invMgmtHTTP.post(this.invMgmtUrl, rcvdBikeInfoRec);
  }
  insPriceData(rcvdPriceDetails:any){
    return this.invMgmtHTTP.post(this.priceDetailsUrl,rcvdPriceDetails);
  }
  viewbikeByName(){
    return this.invMgmtHTTP.get(this.viewBikeDetailsUrl);
  }
  showAllPriceDetails(){
    return this.invMgmtHTTP.get(this.viewPriceDetailsUrl);
  }
}
