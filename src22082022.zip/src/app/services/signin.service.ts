import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { loginuserdetails, userdetails } from '../shared/model/userdetails';

@Injectable({
  providedIn: 'root'
})
export class SigninService {
  signInUrl="http://localhost:9192/signin";
  constructor(private signInHttp:HttpClient) { }
  signInData(recvdSignInRac:loginuserdetails){
    
    return this.signInHttp.post(this.signInUrl,recvdSignInRac)
    // console.log(recvdSignInRac);
    // console.log(recvdSignInRac);
  }
}
