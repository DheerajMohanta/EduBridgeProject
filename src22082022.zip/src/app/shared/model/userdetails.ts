export interface userdetails{
    f_name?:string;
    l_name?:string;
    hnum?:string;
    street?:string;
    addType?:string;
    phnnum?:string;
    lochint?:string;
    p_office?:string;
    state?:string;
    country?:string;
    pin?:Number;
    email?:string;
    gender?:string;
}
export interface loginuserdetails{
    id:number;
    f_name:string;
    phnnum:string;
    email:string;
    passToken:string;
}