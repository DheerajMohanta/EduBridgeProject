export class globalConst{
    public userId!:Number;
    public userFname!:String;
    public emailAddr!:String;
}