import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { SigninService } from 'src/app/services/signin.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  public loggedInUserName!: any;
  public loggedInUserLName!:any;
  public loggedInUserEmail!:any;
  public loggedInUserId!:any;

  constructor(private signInObj:SigninService, private route:Router) { }
  public userInfo:any;
  signInInfo(signInRec:NgForm){  
    console.log(signInRec)   ;
     this.signInObj.signInData(signInRec.value).subscribe((response :any)=>{
      console.log(response);
      const userDetails=response;
      localStorage.setItem('userId', userDetails.id);
      localStorage.setItem('userFname', userDetails.f_name);
      localStorage.setItem('useremail', userDetails.email);
      localStorage.setItem('userphnnum', userDetails.phnnum);
      localStorage.setItem('userLname', userDetails.l_name);
      
      this.route.navigate(['dashboard']);
      
    },error=>alert("Invalid Credentials!! Please try again"));
  }


  ngOnInit(): void {
  }

}
