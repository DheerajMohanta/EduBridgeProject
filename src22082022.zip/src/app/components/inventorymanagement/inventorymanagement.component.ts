import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InventorymanagementService } from 'src/app/services/inventorymanagement.service';

@Component({
  selector: 'app-inventorymanagement',
  templateUrl: './inventorymanagement.component.html',
  styleUrls: ['./inventorymanagement.component.css']
})
export class InventorymanagementComponent implements OnInit {

  constructor(private invMgmtObj:InventorymanagementService,private router:Router) { }

  ngOnInit(): void {
  }

  insertBikeInfo(insBikeInfoRec:any){
    console.log(insBikeInfoRec.value);
    this.invMgmtObj.insBikeInfoData(insBikeInfoRec.value).subscribe(  response=>{
      alert("Insertion Successfull!!");
      this.router.navigate(['product']);
    },error=>alert("Please try again"));
  };
  insertPriceDtls(priceDetailsRec:any){
    console.log(priceDetailsRec.value);
    this.invMgmtObj.insPriceData(priceDetailsRec.value).subscribe(  response=>{
      alert("Insertion Successfull!!");
      // this.router.navigate(['product']);
    },error=>alert("Please try again"));
  }
  onFileSelected(event:any){
    console.log(event);
    if(event.target.files){
      const file=event.target.files[0];
    }
  }
  onFileChanged(event:any){}
  onUpload(){}
  getImage(){}

}
