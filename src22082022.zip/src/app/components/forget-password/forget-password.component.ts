import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ForgetpasswordService } from 'src/app/services/forgetpassword.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  constructor(private passUpdObj:ForgetpasswordService, private route:Router) { }
  updatePassword(passTokenRec:any){
    // console.log(signInRec.value);
    this.passUpdObj.findUser(passTokenRec.value).subscribe(response=>{
      // alert("Login Successfull!!");
      this.passUpdObj.updatePasswordInfo(passTokenRec.value).subscribe(   response=>{
        alert("Password Re-generated Successfull!!");
        this.route.navigate(['signin']);
      },error=>alert("Password re-generations is not successfull!! Please try again"));
      this.route.navigate(['home']);
    },error=>alert("Please enter registered email address and try again!!"));
  }
  ngOnInit(): void {
  }

}
