import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, FormArray, FormBuilder} from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormField, MatHint, MatLabel } from '@angular/material/form-field';
import { Router } from '@angular/router';
import { SignupService } from 'src/app/services/signup.service';
import { RetypeConfirm } from 'src/app/shared/validators/confirmPasswordValidator';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
  
})
export class SignupComponent implements OnInit {

  constructor(private regObj:SignupService, private router:Router) { 

  }/**create object for service */
/*Pass data from Registration form*/
  insUserInfo(insRegInfoRec:any){/**method getting called from API with user given data */
    console.log(insRegInfoRec.value);
    this.regObj.insertRegData(insRegInfoRec.value).subscribe(   response=>{
      alert("Registration Successfull!!");
      this.router.navigate(['signin']);
    },error=>alert("Registration not successfull!! Please try again"));/* calling service method. Subscribing the service the method insertRegData to process the received data */    
  }

  mobNumberPattern = "^((\\+91-?)|0)?[0-9]{10}$";  
  passwordPtn ='^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,16}$'
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
  
  ngOnInit() {
    this.state=this.regObj.state(); 
    console.log(this.state);
  }
  state:any=[];
city:any=[];

  // onSelect(state: { targaet: { value: any; }; }){
    onSelect(state:any) {
    // console.log(state.target.value);
    this.city=this.regObj.city().filter(e=> e.id==state.target.value);
    // console.log(this.city);
  }
}
