import { Component, OnInit, Input, Output } from '@angular/core';
import { InventorymanagementService } from 'src/app/services/inventorymanagement.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  // @Input() signInData:any;
  constructor(private bikeDtlsObj:InventorymanagementService) { 
    this.bikeDetailInfo();
  }

  ngOnInit(): void {
  }
  bikeInfo:any=0;
  bikeDetailInfo(){
    
    this.bikeDtlsObj.viewbikeByName().subscribe((response:any)=>{this.bikeInfo=response}
    );
    console.log(this.bikeInfo);
  }
}
