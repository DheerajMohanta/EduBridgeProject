import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SigninService } from 'src/app/services/signin.service';
import { FormGroup,FormControl, NgForm } from '@angular/forms';
import {userdetails,loginuserdetails} from '../../shared/model/userdetails'
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private signInObj:SigninService, private route:Router, private actrout:ActivatedRoute) { }
  // public userDetails:any;
  public userInfo:any;
  signInInfo(signInRec:NgForm){  
    console.log(signInRec)   ;
     this.signInObj.signInData(signInRec.value).subscribe((response :any)=>{
      console.log(response);
      const userDetails=response;
      localStorage.setItem('userId', userDetails.id);
      localStorage.setItem('userFname', userDetails.f_name);
      localStorage.setItem('useremail', userDetails.email);
      localStorage.setItem('userphnnum', userDetails.phnnum);
      localStorage.setItem('userLname', userDetails.l_name);
      this.route.navigate(['home']);
      // if(response!=null){
      //   // 
      //   localStorage.setItem('userDetails',JSON.stringify(response));
      //   // console.log(response);
      //   this.userInfo=localStorage.getItem('userDetails');
      //   console.log('this.userInfo:',JSON.parse(this.userInfo)); 
      //   this.route.navigate(['home']);
      // }
    },error=>alert("Invalid Credentials!! Please try again"));


    //   alert("Login Successfull!!");     
    //   localStorage.setItem('userDetails',JSON.stringify(response)) ;
    //   console.log("Local Storage" + this.userDetails);
    //   sessionStorage.setItem(this.userInfo,JSON.stringify(response))
    //   console.log("SessionStorage" + this.userInfo);




      // this.userInfo=localStorage.getItem(this.userDetails);
      // if(this.userDetails!=null){
      //   return JSON.parse(this.userDetails);
      // }
      // else{
      //   localStorage.removeItem(this.userDetails);
      //   localStorage.removeItem(this.userDetails);
      //   return null;
      // }



      // this.userDetails,JSON.stringify(response);
      // sessionStorage.setItem(this.userDetails,JSON.stringify(response))
      // sessionStorage.setItem('loggedInUserDetails',JSON.stringify(response))
      // this.userDetails=sessionStorage.getItem('loggedInUserDetails');
      // console.log("Data from SignIn"+this.userDetails);
      // console.log(sessionStorage.getItem('loggedInUserDetails'));

      // console.log(JSON.parse(sessionStorage.getItem('loggedInUserDetails')));      
      
    //   this.route.navigate(['home']);
    // },error=>alert("Invalid Credentials!! Please try again"));

  }

  ngOnInit(): void {
  } 
}

