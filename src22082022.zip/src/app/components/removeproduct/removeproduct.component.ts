import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-removeproduct',
  templateUrl: './removeproduct.component.html',
  styleUrls: ['./removeproduct.component.css']
})
export class RemoveproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
