import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public loggedInUserName!: any;
  public loggedInUserLName!:any;
  public loggedInUserEmail!:any;
  public loggedInUserId!:any;

  constructor() { }
  ngOnInit(): void {
  }
 loggedIn(){
  this.loggedInUserId=localStorage.getItem('userId');
  this.loggedInUserName=localStorage.getItem('userFname');
   this.loggedInUserLName=localStorage.getItem('userLname');
  this.loggedInUserEmail=localStorage.getItem('useremail');
 
  return this.loggedInUserName, this.loggedInUserEmail;
 }
 logout(){
  localStorage.clear();
 }
}
