import { Component, OnInit, Input, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-navigator',
  templateUrl: './navigator.component.html',
  styleUrls: ['./navigator.component.css']
})
export class NavigatorComponent implements OnInit {
  
  public loggedInUserName!: any;
  public loggedInUserLName!:any;
  public loggedInUserEmail!:any;
  public loggedInUserId!:any;

  constructor() { }
  ngOnInit(): void {
  }
 loggedIn(){
  this.loggedInUserId=localStorage.getItem('userId');
  this.loggedInUserName=localStorage.getItem('userFname');
   this.loggedInUserLName=localStorage.getItem('userLname');
  this.loggedInUserEmail=localStorage.getItem('useremail');
 
  return this.loggedInUserName, this.loggedInUserEmail;
 }
 logout(){
  localStorage.clear();
 }
  
  
}
