import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { CustomerdetailsComponent } from './components/customerdetails/customerdetails.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { HomeComponent } from './components/home/home.component';
import { InventorymanagementComponent } from './components/inventorymanagement/inventorymanagement.component';
import { RemoveproductComponent } from './components/removeproduct/removeproduct.component';
import { SigninComponent } from './components/signin/signin.component';
import { SignoutComponent } from './components/signout/signout.component';
import { SignupComponent } from './components/signup/signup.component';
import { OrderComponent } from './order/order.component';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
  {path:'',redirectTo:'home', pathMatch:'full'},// if path is blank, then redirect to home page
  {path:'signin',component:SigninComponent},
  {path:'home',component:HomeComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'signout',component:SignoutComponent},
  {path:'signup',component:SignupComponent},
  {path:'forgetPassword',component:ForgetPasswordComponent},
  {path: 'product',component:ProductComponent},
  {path: 'addproduct',component:AddproductComponent},
  {path: 'deleteproduct',component:RemoveproductComponent},
  {path: 'adminsignin',component:AdminloginComponent},
  {path: 'mgntinventory',component:InventorymanagementComponent},
  {path: 'orders',component:OrderComponent},
  {path:'customers',component:CustomerdetailsComponent},
  {path: 'checkout',component:CheckoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
